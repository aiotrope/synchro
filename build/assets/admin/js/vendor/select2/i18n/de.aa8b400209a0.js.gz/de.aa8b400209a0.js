/*! Select2 4.0.13 | https://github.com/select2/select2/blob/master/LICENSE.md */

!(function () {
  if (jQuery && jQuery.fn && jQuery.fn.select2 && jQuery.fn.select2.amd)
    var e = jQuery.fn.select2.amd
  e.define('select2/i18n/de', [], function () {
    return {
      errorLoading: function () {
        return 'Die Ergebnisse konnten nicht geladen werden.'
      },
      inputTooLong: function (e) {
        return (
          'Bitte ' + (e.input.length - e.maximum) + ' Zeichen weniger eingeben'
        )
      },
      inputTooShort: function (e) {
        return (
          'Bitte ' + (e.minimum - e.input.length) + ' Zeichen mehr eingeben'
        )
      },
      loadingMore: function () {
        return 'Lade mehr Ergebnisse…'
      },
      maximumSelected: function (e) {
        var n = 'Sie können nur ' + e.maximum + ' Element'
        return 1 != e.maximum && (n += 'e'), (n += ' auswählen')
      },
      noResults: function () {
        return 'Keine Übereinstimmungen gefunden'
      },
      searching: function () {
        return 'Suche…'
      },
      removeAllItems: function () {
        return 'Entferne alle Elemente'
      },
    }
  }),
    e.define,
    e.require
})()
